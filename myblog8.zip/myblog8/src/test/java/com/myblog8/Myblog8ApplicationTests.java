package com.myblog8;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Myblog8ApplicationTests {

	@Test
	void contextLoads() {
	}

}
